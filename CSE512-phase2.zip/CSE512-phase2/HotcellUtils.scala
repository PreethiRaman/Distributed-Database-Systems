package cse512

import java.sql.Timestamp
import java.text.SimpleDateFormat
import java.util.Calendar

object HotcellUtils {
  val coordinateStep = 0.01

  def CalculateCoordinate(inputString: String, coordinateOffset: Int): Int =
  {
    // Configuration variable:
    // Coordinate step is the size of each cell on x and y
    var result = 0
    coordinateOffset match
    {
      case 0 => result = Math.floor((inputString.split(",")(0).replace("(","").toDouble/coordinateStep)).toInt
      case 1 => result = Math.floor(inputString.split(",")(1).replace(")","").toDouble/coordinateStep).toInt
      // We only consider the data from 2009 to 2012 inclusively, 4 years in total. Week 0 Day 0 is 2009-01-01
      case 2 => {
        val timestamp = HotcellUtils.timestampParser(inputString)
        result = HotcellUtils.dayOfMonth(timestamp) // Assume every month has 31 days
      }
    }
    return result
  }

  def timestampParser (timestampString: String): Timestamp =
  {
    val dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss")
    val parsedDate = dateFormat.parse(timestampString)
    val timeStamp = new Timestamp(parsedDate.getTime)
    return timeStamp
  }

  def dayOfYear (timestamp: Timestamp): Int =
  {
    val calendar = Calendar.getInstance
    calendar.setTimeInMillis(timestamp.getTime)
    return calendar.get(Calendar.DAY_OF_YEAR)
  }

  def dayOfMonth (timestamp: Timestamp): Int =
  {
    val calendar = Calendar.getInstance
    calendar.setTimeInMillis(timestamp.getTime)
    return calendar.get(Calendar.DAY_OF_MONTH)
  }

  def calculateSquare (x:Int) : Double =
  {
    (x * x).toDouble
  }

  def calculateAdjCells(inputX: Int, minX: Int, maxX: Int, inputY: Int, minY: Int, maxY: Int, inputZ: Int, minZ: Int, maxZ: Int): Int =
  {
    var counter = 0
    var result = 0
    
    if (inputX == maxX || inputX == minX) {
      counter = counter + 1
    }

    if (inputY == maxY || inputY == minY ) {
      counter = counter + 1
    } 

    if (inputZ == maxZ || inputZ == minZ) {
      counter = counter + 1
    }

    if (counter == 1) { result =  17; } 
    else if (counter == 2) { result = 11; } 
    else if (counter == 3) { result = 7; }
    else { result =26; }
    return result;
  }

  def calculateZScore(mean: Double, std: Double, totalSum: Int, neighborCount: Int, numCells: Int): Double =
  {
    val num = totalSum.toDouble - (mean * neighborCount.toDouble)
    val den = std * math.sqrt(((numCells.toDouble * neighborCount.toDouble) - (neighborCount.toDouble * neighborCount.toDouble))/(numCells.toDouble - 1.0))
    return num / den
  }
}
