package cse512

object HotzoneUtils {

  def ST_Contains(queryRectangle: String, pointString: String ): Boolean = {
    	var npoint = pointString.split(",")
        var gx = npoint(0).toDouble
        var gy = npoint(1).toDouble
        
        var nrect = queryRectangle.split(",")
        var p1x = nrect(0).toDouble
        var p1y = nrect(1).toDouble
        var p2x = nrect(2).toDouble
        var p2y = nrect(3).toDouble
        
        var minx = math.min(p1x, p2x)
        var miny = math.min(p1y, p2y)
        var maxx = math.max(p1x, p2x)
        var maxy = math.max(p1y, p2y)
        
        if (minx<=gx && gx<=maxx && miny<=gy && gy<=maxy) {
          return true
        }
        else{
          return false
        }
  }


}
