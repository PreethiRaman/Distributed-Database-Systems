import threading
import psycopg2
import os
import sys


# Donot close the connection inside this file i.e. do not perform openconnection.close()
def ParallelSort (InputTable, SortingColumnName, OutputTable, openconnection):
    #Implement ParallelSort Here.
    cur = openconnection.cursor()
    try:
        x = 5
        threads = [0 for i in range(x)]

        cur.execute("select max(" + SortingColumnName + ") from " +InputTable)
        mav = cur.fetchone()[0]
        cur.execute("select min(" + SortingColumnName + ") from " +InputTable)
        miv = cur.fetchone()[0]
        intr = float(mav - miv)/float(x)

        for i in range(0,x):
            low = miv + intr * i
            high = low + intr
            threads[i] = threading.Thread(target = sort, args=(InputTable, SortingColumnName, i, low, high, openconnection))
            threads[i].start()
        cur.execute("DROP TABLE IF EXISTS " +OutputTable)
        cur.execute("create table " + OutputTable + "(like " + InputTable+ ")")

        for i in range(0,x):
            threads[i].join()
            table = 'sort_table'+str(i)
            cur.execute("insert into " + OutputTable + " select * from " +table)
            cur.execute("DROP TABLE IF EXISTS " +table)
        openconnection.commit()
    except psycopg2.DatabaseError as e:
        if openconnection:
            openconnection.rollback()
        print('Error %s' % e)
        sys.exit(1)
    except IOError as e:
        if openconnection:
            openconnection.rollback()
        print('Error %s' % e)
        sys.exit(1)
    finally:
        if cur:
            cur.close()

def sort(InputTable, SortingColumnName, i, low, high, openconnection):
    cur = openconnection.cursor()
    table = 'sort_table' + str(i)
    cur.execute("create table " + table + " ( like " + InputTable + ")")
    if i == 0:
        cur.execute("insert into " + table + " select * from " + InputTable + " where " + SortingColumnName + ">=" + str(low) + " and " + SortingColumnName + "<=" +str(high) + " order by " + SortingColumnName + " asc ")
    else:
        cur.execute("insert into " + table + " select * from " + InputTable + " where " + SortingColumnName + ">" + str(low) + " and " + SortingColumnName + "<=" +str(high) + " order by " + SortingColumnName + " asc ")



def ParallelJoin (InputTable1, InputTable2, Table1JoinColumn, Table2JoinColumn, OutputTable, openconnection):
    cur = openconnection.cursor()
    try:
        x = 5
        threads = [0 for i in range(x)]

        cur.execute("select min(" + Table1JoinColumn + ") from " + InputTable1)
        mini1 = cur.fetchone()[0]
        cur.execute("select max(" + Table1JoinColumn + ") from " + InputTable1)
        maxi1 = cur.fetchone()[0]
        cur.execute("select min(" + Table2JoinColumn + ") from " + InputTable2)
        mini2 = cur.fetchone()[0]
        cur.execute("select max(" + Table2JoinColumn + ") from " + InputTable2)
        maxi2 = cur.fetchone()[0]

        miv = min(mini1,mini2)
        mav = max(maxi1,maxi2)

        intr = float(mav-miv)/float(x)

        cur.execute("select column_name,data_type from information_schema.columns where table_name = '" + InputTable1 + "'")
        input_table1_schema = cur.fetchall()

        cur.execute("select column_name,data_type from information_schema.columns where table_name = '" + InputTable2 + "'")
        input_table2_schema = cur.fetchall()

        for i in range(0,x):
            low = miv + intr * i
            high = low + intr
            threads[i] = threading.Thread(target = join, args=(InputTable1,InputTable2,i,input_table1_schema,input_table2_schema,Table1JoinColumn,Table2JoinColumn,low,high,openconnection))
            threads[i].start()
        cur.execute("DROP TABLE IF EXISTS " +OutputTable)
        cur.execute("create table " + OutputTable + " ( like " + InputTable1 + ")")

        for i in range(0,len(input_table2_schema)):
            cur.execute("alter table " + OutputTable + " add column " + input_table2_schema[i][0] + " " + input_table2_schema[i][1])
        for i in range(x):
            threads[i].join()
            table = 'table_output'+str(i)
            cur.execute("insert into " + OutputTable + " select * from " + table)
        for i in range(5):
            cur.execute("DROP TABLE IF EXISTS table1_name" +str(i))
            cur.execute("DROP TABLE IF EXISTS table2_name"+str(i))
            cur.execute("DROP TABLE IF EXISTS table_output"+str(i))
        openconnection.commit()
    except psycopg2.DatabaseError as e:
        if openconnection:
            openconnection.rollback()
        print('Error %s' % e)
        sys.exit(1)
    except IOError as e:
        if openconnection:
            openconnection.rollback()
        print('Error %s' % e)
        sys.exit(1)
    finally:
        if cur:
            cur.close()

def join(InputTable1,InputTable2,i,InputTable1_schema,InputTable2_schema,Table1JoinColumn,Table2JoinColumn,low,high,openconnection):
    cur = openconnection.cursor()

    table1_name = 'table1_name' + str(i)
    cur.execute("create table " + table1_name + " ( like " + InputTable1 + ")")
    table2_name = 'table2_name' + str(i)
    cur.execute("create table " + table2_name + " ( like " + InputTable2 + ")")
    table = 'table_output'+str(i)
    cur.execute("create table " + table + " ( like " + InputTable1 + ")")

    for j in range(0,len(InputTable2_schema)):
        cur.execute("alter table " + table + " add column " + InputTable2_schema[j][0] + " " + InputTable2_schema[j][1])

    if i==0:
        cur.execute("insert into " + table1_name + " select * from " + InputTable1 + " where " + Table1JoinColumn + " >= " + str(low) + " and " + Table1JoinColumn + " <= " + str(high))
        cur.execute("insert into " + table2_name + " select * from " + InputTable2 + " where " + Table2JoinColumn + " >= " + str(low) + " and " + Table2JoinColumn + " <= " + str(high))
    else:
        cur.execute("insert into " + table1_name + " select * from " + InputTable1 + " where " + Table1JoinColumn + " > " + str(low) + " and " + Table1JoinColumn + " <= " + str(high))
        cur.execute("insert into " + table2_name + " select * from " + InputTable2 + " where " + Table2JoinColumn + " > "+ str(low) + " and " + Table2JoinColumn + " <= " + str(high) + " order by " + Table2JoinColumn + " asc ")
    cur.execute("insert into " + table + " select * from " + table1_name + " inner join " + table2_name + " on " + table1_name + "." + Table1JoinColumn + " = " + table2_name + "." + Table2JoinColumn)
        


################### DO NOT CHANGE ANYTHING BELOW THIS #############################


# Donot change this function
def getOpenConnection(user='postgres', password='1234', dbname='ddsassignment3'):
    return psycopg2.connect("dbname='" + dbname + "' user='" + user + "' host='localhost' password='" + password + "'")

# Donot change this function
def createDB(dbname='ddsassignment3'):
    """
    We create a DB by connecting to the default user and database of Postgres
    The function first checks if an existing database exists for a given name, else creates it.
    :return:None
    """
    # Connect to the default database
    con = getOpenConnection(dbname='postgres')
    con.set_isolation_level(psycopg2.extensions.ISOLATION_LEVEL_AUTOCOMMIT)
    cur = con.cursor()

    # Check if an existing database with the same name exists
    cur.execute('SELECT COUNT(*) FROM pg_catalog.pg_database WHERE datname=\'%s\'' % (dbname,))
    count = cur.fetchone()[0]
    if count == 0:
        cur.execute('CREATE DATABASE %s' % (dbname,))  # Create the database
    else:
        print('A database named {0} already exists'.format(dbname))

    # Clean up
    cur.close()
    con.commit()
    con.close()

# Donot change this function
def deleteTables(ratingstablename, openconnection):
    try:
        cursor = openconnection.cursor()
        if ratingstablename.upper() == 'ALL':
            cursor.execute("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public'")
            tables = cursor.fetchall()
            for table_name in tables:
                cursor.execute('DROP TABLE %s CASCADE' % (table_name[0]))
        else:
            cursor.execute('DROP TABLE %s CASCADE' % (ratingstablename))
        openconnection.commit()
    except psycopg2.DatabaseError as e:
        if openconnection:
            openconnection.rollback()
        print('Error %s' % e)
        sys.exit(1)
    except IOError as e:
        if openconnection:
            openconnection.rollback()
        print('Error %s' % e)
        sys.exit(1)
    finally:
        if cursor:
            cursor.close()


