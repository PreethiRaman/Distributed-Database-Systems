#
# Assignment5 Interface
# Name: Preethi Raman
#

from pymongo import MongoClient
import os
import sys
import json
import re
import math 

def FindBusinessBasedOnCity(cityToSearch, saveLocation1, collection):
    #cmd = { "city": re.compile(cityToSearch, re.IGNORECASE) }
    cmd = {"city": re.compile('^' + re.escape(cityToSearch) + '$', re.IGNORECASE)}
    result = collection.find(cmd)
    with open(saveLocation1, 'w') as output:
        for i in result:
            name = i['name']
            addr = i['full_address'].replace("\n", ", ")
            city = i['city']
            state = i['state']
            output.write(name.upper() + "$" + addr.upper() + "$" + city.upper() + "$" + state.upper() + "\n")
    output.close()

def FindBusinessBasedOnLocation(categoriesToSearch, myLocation, maxDistance, saveLocation2, collection):
    cmd = {"categories": { "$in": categoriesToSearch }}
    result = collection.find(cmd)
    latitudes1 = myLocation[0]
    longitudes1 =myLocation[1]
    with open(saveLocation2, 'w') as output:
        for i in result:
            latitudes2 = float(i['latitude'])
            longitudes2 = float(i['longitude'])
            name = i['name']
            if(distcalc(latitudes2, longitudes2, float(latitudes1), float(longitudes1)) <= maxDistance):
                output.write(name.upper() + "\n")
    output.close()

def distcalc(latitudes2, longitudes2, latitudes1, longitudes1):
    R = 3959
    fi1 = math.radians(latitudes1)
    fi2 = math.radians(latitudes2)
    deltafi = math.radians(latitudes2-latitudes1)
    deltalam = math.radians(longitudes2-longitudes1)
    a = (math.sin(deltafi/2) * math.sin(deltafi/2)) + (math.cos(fi1) * math.cos(fi2) * math.sin(deltalam/2) * math.sin(deltalam/2))
    c = 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))
    d=R*c
    return d


