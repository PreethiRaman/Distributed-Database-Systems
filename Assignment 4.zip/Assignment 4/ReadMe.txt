Driver:
Driver calls the map and reduce functions and creates a job.
It gets the input and output directory from the arguments.
It exits when the job is completed.     

Mapper:
Mapper takes your input.txt file as the input. 
It processes each line of the input file and checks if any two tables have same join column value and creates a key-value pair for those kind of tables.
The key would be the join column name and the value would be the other columns of the tables.
While creating this key-value pair, comma and space is appended appropriately in the value according to the output.

Reducer
Reducer takes the output of Mapper as its input.
It separates rows related to table1 and table2 and place them in two lists. All the combinations of elements in these two list are generated and written to the output. These combinations make up the rows in the equijoin.

Hadoop Commands to execute the jar file:
Inside bin folder of Hadoop:

hadoop jar <location_of_jar_file>equijoin.jar equijoin <Location_of_input_file>  <Location_of_output_file>

Example: 
hadoop jar /Users/Preethi/Desktop/DDSAssign4/equijoin.jar equijoin file:////Users/Preethi/Desktop/DDSAssign4/input.txt file:////Users/Preethi/Desktop/DDSAssign4/output.txt

To place input file in Hadoop:
./hadoop fs -put <Input_file_path> /

Example:
./hadoop fs -get /output.txt /Users/Preethi/Desktop/DDSAssign4/

To remove your file from Hadoop:
./hadoop fs -rm -r /<File_name>

Example:
./hadoop fs -rm -r /output.txt

If it encounters any permission error, add the following configuration to the hdfs-site.xml file

<property>
  <name>dfs.permissions</name>
  <value>false</value>
</property>