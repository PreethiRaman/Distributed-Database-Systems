import java.io.IOException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.StringTokenizer;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.DoubleWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;


public class equijoin {

	public static class Map extends Mapper<LongWritable, Text, DoubleWritable, Text> {
		private Text opval = new Text();

		private DoubleWritable opkey = new DoubleWritable();

		public void map(LongWritable key, Text val, Context context) throws IOException, InterruptedException {
			String[] tokens = val.toString().split(",");
			String result = "";
			
			for(int i=0;i<tokens.length;i++)
			{
				result = result + tokens[i].trim().toString();
				if(i!=tokens.length-1)
					result=result+", ";
			}
			opval.set(new Text(result));
			opkey.set(Double.parseDouble(tokens[1].trim().toString()));
			context.write(opkey, opval);
						
		}	
	}

	public static class Reduce extends Reducer<DoubleWritable, Text, Object, Text> {

		public void reduce(DoubleWritable key, Iterable<Text> values, Context context)
				throws IOException, InterruptedException {
			List<String> tot1 = new ArrayList<String>();
			List<String> tot2 = new ArrayList<String>();
			Set<String> wordsset = new HashSet<String>();
			Text outputText = new Text();
			StringBuilder outputStringBuilder = new StringBuilder();
			String t1 = null;
			for (Text val : values) 
			{
				wordsset.add(val.toString());
			}
			List<String> words = new ArrayList<String>();
			words.addAll(wordsset);
			if(words.size() < 2) 
			{
				return;
			} else
			{
				t1 = words.get(0).split(", ")[0];
				for (String word : words) 
				{
					if (t1.equals(word.split(", ")[0])) 
					{
						tot1.add(word);
					} 
					else 
					{
						tot2.add(word);
					}
				}
				if(tot1.size() == 0 || tot2.size() == 0) 
				{
					return;
				}
				else 
				{
					for (String tab1t : tot1) 
					{
						for (String tab2t : tot2)
						{
							outputStringBuilder.append(tab1t).append(", ").append(tab2t).append("\n");
						}
					}
					outputText.set(outputStringBuilder.toString().trim());
					context.write(null, outputText);
					
				}
			}
		}
	}
	
	public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
		Configuration conf = new Configuration();
		Job j = new Job(conf, "equijoin");
		j.setJarByClass(equijoin.class);
		j.setMapperClass(Map.class);
		FileInputFormat.addInputPath(j, new Path(args[0]));
		FileOutputFormat.setOutputPath(j, new Path(args[1]));
		j.setOutputKeyClass(Object.class);
		j.setOutputValueClass(Text.class);
		j.setReducerClass(Reduce.class);
		j.setMapOutputKeyClass(DoubleWritable.class);
		j.setMapOutputValueClass(Text.class);
		System.exit(j.waitForCompletion(true) ? 0 : 1);
	}

}

